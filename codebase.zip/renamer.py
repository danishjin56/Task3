#!/usr/bin/env python3
"""Batch file renaming CLI tool with dry-run preview, conflict detection,
rollback/undo, and interactive confirmation."""

import argparse
import datetime
import fnmatch
import json
import os
import pathlib
import re
import sys
import time
import unicodedata

try:
    import yaml
except ImportError:
    yaml = None


# ---------------------------------------------------------------------------
# Natural Sort Key
# ---------------------------------------------------------------------------

def natural_sort_key(name: str) -> list[int | str]:
    """Split *name* into a list of string and integer segments so that
    ``sorted(files, key=natural_sort_key)`` orders them in human-natural
    order (e.g. ``file2`` before ``file10``)."""
    parts: list[int | str] = []
    for tok in re.split(r'(\d+)', name):
        if tok.isdigit():
            parts.append(int(tok))
        else:
            parts.append(tok.lower())
    return parts


# ---------------------------------------------------------------------------
# Slugify
# ---------------------------------------------------------------------------

def slugify(text: str, separator: str) -> str:
    """Strip accented characters to ASCII equivalents, replace spaces and
    non-alphanumeric characters with *separator*, collapse consecutive
    separators, and strip leading/trailing separators."""
    # NFKD decomposition → strip combining marks
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = ''.join(ch for ch in nfkd if not unicodedata.combining(ch))
    # Replace non-alphanumeric with separator
    result = re.sub(r'[^a-zA-Z0-9]+', separator, ascii_text)
    # Collapse consecutive separators
    if separator:
        result = re.sub(re.escape(separator) + r'+', separator, result)
    # Strip leading/trailing separators
    result = result.strip(separator)
    return result


# ---------------------------------------------------------------------------
# Apply Operations Pipeline
# ---------------------------------------------------------------------------

def apply_operations(filename: str, operations: list[dict],
                     file_path: pathlib.Path, file_index: int = 0) -> str:
    """Apply each operation dict in order to the filename stem (and extension
    for ``ext-change``).  Returns the fully transformed filename."""
    stem = pathlib.PurePath(filename).stem
    ext = pathlib.PurePath(filename).suffix  # includes dot

    for op in operations:
        op_type = op['type']

        if op_type == 'find-replace':
            stem = stem.replace(op['old'], op['new'])

        elif op_type == 'regex-replace':
            stem = re.sub(op['pattern'], op['repl'], stem)

        elif op_type == 'case':
            mode = op['mode']
            if mode == 'lower':
                stem = stem.lower()
            elif mode == 'upper':
                stem = stem.upper()
            elif mode == 'title':
                stem = stem.title()

        elif op_type == 'number':
            pos = op['position']
            start = int(op['start'])
            step = int(op['step'])
            pad = int(op['pad'])
            counter = str(start + file_index * step).zfill(pad)
            if pos == 'prefix':
                stem = counter + stem
            else:
                stem = stem + counter

        elif op_type == 'date-insert':
            fmt = op['format']
            pos = op['position']
            mtime = file_path.stat().st_mtime
            dt = datetime.datetime.fromtimestamp(mtime)
            date_str = dt.strftime(fmt)
            if pos == 'prefix':
                stem = date_str + stem
            else:
                stem = stem + date_str

        elif op_type == 'slugify':
            sep_name = op.get('separator', 'hyphen')
            sep_char = '-' if sep_name == 'hyphen' else '_'
            stem = slugify(stem, sep_char)

        elif op_type == 'prefix':
            stem = op['string'] + stem

        elif op_type == 'suffix':
            stem = stem + op['string']

        elif op_type == 'ext-change':
            new_ext = op['new_ext']
            if not new_ext.startswith('.'):
                new_ext = '.' + new_ext
            ext = new_ext

        elif op_type == 'trim-chars':
            pattern = op['pattern']
            stem = stem.strip(pattern)

        elif op_type == 'pad-numbers':
            width = int(op['width'])
            stem = re.sub(r'\d+', lambda m: m.group().zfill(width), stem)

    return stem + ext


# ---------------------------------------------------------------------------
# Select Files
# ---------------------------------------------------------------------------

def _normalize_ext(ext: str) -> str:
    """Normalize an extension string: lowercase, strip leading dots."""
    return ext.lstrip('.').lower()


def select_files(directory: pathlib.Path, pattern: str, recursive: bool,
                 ext_filter: list[str] | None, ext_exclude: list[str] | None,
                 natural_sort: bool) -> list[pathlib.Path]:
    """Locate valid targets under *directory* matching *pattern*."""
    matched: list[pathlib.Path] = []

    if recursive:
        candidates = list(directory.rglob(pattern))
    else:
        candidates = list(directory.glob(pattern))

    # Only files
    candidates = [p for p in candidates if p.is_file()]

    # Extension filtering
    if ext_filter is not None:
        norm_filter = [_normalize_ext(e) for e in ext_filter]
        filtered = []
        for p in candidates:
            file_ext = _normalize_ext(p.suffix)  # suffix includes dot
            if file_ext in norm_filter or ('' in norm_filter and p.suffix == ''):
                filtered.append(p)
        candidates = filtered

    if ext_exclude is not None:
        norm_exclude = [_normalize_ext(e) for e in ext_exclude]
        filtered = []
        for p in candidates:
            file_ext = _normalize_ext(p.suffix)
            if file_ext not in norm_exclude and not ('' in norm_exclude and p.suffix == ''):
                filtered.append(p)
        candidates = filtered

    matched = candidates

    if natural_sort:
        matched.sort(key=lambda p: natural_sort_key(p.name))
    else:
        matched.sort()

    return matched


# ---------------------------------------------------------------------------
# Load Recipe
# ---------------------------------------------------------------------------

def load_recipe(recipe_path: str) -> list[dict]:
    """Parse a YAML recipe file and return a list of operation dicts."""
    if yaml is None:
        raise ImportError("PyYAML is required for recipe files. Install with: pip install pyyaml")
    with open(recipe_path, 'r') as f:
        data = yaml.safe_load(f)
    ops: list[dict] = []
    for entry in data.get('operations', []):
        op = dict(entry)
        # Normalize keys to match apply_operations expectations
        op_type = op['type']
        if op_type == 'slugify':
            # Recipe uses 'char' or 'separator'; normalize
            if 'char' in op and 'separator' not in op:
                op['separator'] = op.pop('char')
            elif 'separator' not in op:
                op['separator'] = 'hyphen'
        elif op_type == 'date-insert':
            if 'fmt' in op and 'format' not in op:
                op['format'] = op.pop('fmt')
            if 'pos' in op and 'position' not in op:
                op['position'] = op.pop('pos')
        elif op_type == 'ext-change':
            if 'ext' in op and 'new_ext' not in op:
                op['new_ext'] = op.pop('ext')
        elif op_type == 'pad-numbers':
            if 'n' in op and 'width' not in op:
                op['width'] = op.pop('n')
        elif op_type == 'trim-chars':
            pass  # 'pattern' key used directly
        elif op_type == 'prefix' or op_type == 'suffix':
            if 'value' in op and 'string' not in op:
                op['string'] = op.pop('value')
        elif op_type == 'regex-replace':
            pass  # 'pattern' and 'repl' used directly
        ops.append(op)
    return ops


# ---------------------------------------------------------------------------
# Resolve Target Paths
# ---------------------------------------------------------------------------

_ROLLBACK_PATTERN = re.compile(r'^\.rename_rollback_\d{8}_\d{6}_\d+\.json$')


def resolve_target_paths(rename_plan: list[tuple[pathlib.Path, str]]) -> dict:
    """Take a list of (source_path, proposed_filename) tuples and produce
    a resolution dict with ``proposed_conflicts`` and ``resolved_plan``."""

    source_paths = {item[0] for item in rename_plan}

    # Build proposed targets
    proposed_entries = []
    for source, proposed_name in rename_plan:
        target = source.parent / proposed_name
        proposed_entries.append({
            'source': source,
            'proposed': proposed_name,
            'target': target,
        })

    # --- Detect duplicate proposed targets ---
    target_to_sources: dict[pathlib.Path, list[pathlib.Path]] = {}
    for entry in proposed_entries:
        t = entry['target']
        target_to_sources.setdefault(t, []).append(entry['source'])

    duplicate_groups: list[list[pathlib.Path]] = []
    duplicate_sources: set[pathlib.Path] = set()
    for t, sources in target_to_sources.items():
        if len(sources) > 1:
            duplicate_groups.append(list(sources))
            duplicate_sources.update(sources)

    # --- Detect existing-path collisions (non-batch occupancy) ---
    existing_collisions_list: list[dict] = []
    existing_collision_sources: set[pathlib.Path] = set()
    for entry in proposed_entries:
        t = entry['target']
        if t.exists() and t not in source_paths:
            existing_collisions_list.append({
                'source': entry['source'],
                'collides_with': t,
            })
            existing_collision_sources.add(entry['source'])

    proposed_conflicts = {
        'duplicate_groups': duplicate_groups,
        'existing_collisions': existing_collisions_list,
    }

    # --- Resolve: iterative disambiguation ---
    resolved_plan: list[dict] = []
    used_targets: set[pathlib.Path] = set()

    for entry in proposed_entries:
        source = entry['source']
        proposed_name = entry['proposed']
        target = entry['target']

        is_dup = source in duplicate_sources
        is_col = source in existing_collision_sources

        resolved = target
        attempts = 0

        while True:
            # Check rollback pattern reservation
            if _ROLLBACK_PATTERN.match(resolved.name):
                conflict = True
            # Check in-batch collision
            elif resolved in used_targets:
                conflict = True
            # Check on-disk collision by non-batch path
            elif resolved.exists() and resolved not in source_paths:
                conflict = True
                if not is_col:
                    is_col = True
            else:
                conflict = False

            if not conflict:
                break

            attempts += 1
            stem = pathlib.PurePath(proposed_name).stem
            ext = pathlib.PurePath(proposed_name).suffix
            new_name = f"{stem}_{attempts + 1}{ext}"
            resolved = source.parent / new_name

        used_targets.add(resolved)

        # Stat signature
        try:
            st = source.stat()
            stat_sig = {'size': st.st_size, 'mtime_ns': st.st_mtime_ns}
        except OSError:
            stat_sig = {'size': 0, 'mtime_ns': 0}

        unchanged = (resolved == source)

        resolved_plan.append({
            'source': source,
            'proposed': proposed_name,
            'resolved': resolved,
            'resolution_attempts': attempts,
            'proposed_duplicate': is_dup,
            'existing_collision': is_col,
            'stat_signature': stat_sig,
            'unchanged': unchanged,
        })

    return {
        'proposed_conflicts': proposed_conflicts,
        'resolved_plan': resolved_plan,
    }


# ---------------------------------------------------------------------------
# Dry-Run Preview
# ---------------------------------------------------------------------------

def _highlight_changes(original: str, new: str) -> str:
    """Wrap altered segments in square brackets for display."""
    if original == new:
        return new
    # Simple diff: find common prefix and suffix
    prefix_len = 0
    for a, b in zip(original, new):
        if a == b:
            prefix_len += 1
        else:
            break
    suffix_len = 0
    for a, b in zip(reversed(original), reversed(new)):
        if a == b and suffix_len < len(new) - prefix_len:
            suffix_len += 1
        else:
            break
    if suffix_len == 0:
        changed = new[prefix_len:]
        return new[:prefix_len] + '[' + changed + ']'
    else:
        changed = new[prefix_len:len(new) - suffix_len]
        return new[:prefix_len] + '[' + changed + ']' + new[len(new) - suffix_len:]


def preview_renames(resolution_states: dict) -> dict:
    """Build preview table rows, compute summary counts, and print to stdout."""
    resolved_plan = resolution_states['resolved_plan']

    table_rows: list[dict] = []
    conflicts: list[str] = []
    total_matched = len(resolved_plan)
    to_rename = 0
    unchanged_count = 0
    proposed_conflicts_count = 0
    existing_collisions_count = 0

    for i, entry in enumerate(resolved_plan, 1):
        is_unchanged = entry['unchanged']
        is_dup = entry['proposed_duplicate']
        is_col = entry['existing_collision']

        if is_unchanged:
            status = 'Unchanged'
        elif is_dup and is_col:
            status = 'Flagged Conflict + Collision'
        elif is_dup:
            status = 'Flagged Conflict'
        elif is_col:
            status = 'Flagged Collision'
        else:
            status = 'OK'

        if is_unchanged:
            unchanged_count += 1
        else:
            to_rename += 1

        if is_dup:
            proposed_conflicts_count += 1
        if is_col:
            existing_collisions_count += 1

        current_path = str(entry['source'])
        proposed_target = entry['proposed']
        resolved_target = str(entry['resolved'])
        highlighted = _highlight_changes(current_path, resolved_target)

        row = {
            'row_number': i,
            'current_path': current_path,
            'proposed_target': proposed_target,
            'resolved_target': resolved_target,
            'status': status,
            'proposed_duplicate': is_dup,
            'existing_collision': is_col,
            'unchanged': is_unchanged,
        }
        table_rows.append(row)

    # Generate conflict messages
    pc = resolution_states.get('proposed_conflicts', {})
    for group in pc.get('duplicate_groups', []):
        names = ', '.join(str(s) for s in group)
        conflicts.append(f"Duplicate proposed target for: {names}")
    for col in pc.get('existing_collisions', []):
        conflicts.append(
            f"Existing-path collision: {col['source']} → {col['collides_with']}")

    summary = {
        'total_matched': total_matched,
        'to_rename': to_rename,
        'unchanged': unchanged_count,
        'proposed_conflicts': proposed_conflicts_count,
        'existing_collisions': existing_collisions_count,
    }

    # Print formatted table
    print()
    header = f"{'#':>4}  {'Current Path':<40}  {'Proposed Target':<30}  {'Resolved Target Path':<40}  {'Status'}"
    print(header)
    print('-' * len(header))
    for row in table_rows:
        current = row['current_path']
        proposed = row['proposed_target']
        resolved = row['resolved_target']
        highlighted_resolved = _highlight_changes(
            pathlib.PurePath(current).name, pathlib.PurePath(resolved).name)
        print(f"{row['row_number']:>4}  {current:<40}  {proposed:<30}  {highlighted_resolved:<40}  {row['status']}")
    print()

    # Print conflicts
    for msg in conflicts:
        print(f"  ⚠ {msg}")

    # Print summary
    print(f"\nSummary: {summary['total_matched']} matched, "
          f"{summary['to_rename']} to rename, "
          f"{summary['unchanged']} unchanged, "
          f"{summary['proposed_conflicts']} proposed conflicts, "
          f"{summary['existing_collisions']} existing collisions")
    print()

    return {
        'table_rows': table_rows,
        'conflicts': conflicts,
        'summary': summary,
    }


# ---------------------------------------------------------------------------
# Execute Renames (Two-Phase)
# ---------------------------------------------------------------------------

def execute_renames(resolved_plan: list[dict],
                    directory: pathlib.Path) -> pathlib.Path:
    """Perform all file renames via two-phase strategy.  Returns rollback path."""
    # Filter out unchanged
    actionable = [e for e in resolved_plan if not e.get('unchanged', False)]

    if not actionable:
        # Nothing to do — still write a rollback for consistency
        pass

    source_set = {e['source'] for e in actionable}

    # --- Drift detection ---
    for entry in actionable:
        src = entry['source']
        sig = entry['stat_signature']
        if not src.exists():
            raise RuntimeError(
                f"Drift detected: source file no longer exists: {src}")
        st = src.stat()
        if st.st_size != sig['size'] or st.st_mtime_ns != sig['mtime_ns']:
            raise RuntimeError(
                f"Drift detected: stat signature mismatch for {src}")

    for entry in actionable:
        resolved = entry['resolved']
        if resolved.exists() and resolved not in source_set:
            raise RuntimeError(
                f"Drift detected: target occupied by non-batch path: {resolved}")

    # --- Phase 1: source → temp ---
    temp_map: list[tuple[pathlib.Path, pathlib.Path, pathlib.Path]] = []
    for entry in actionable:
        src = entry['source']
        resolved = entry['resolved']
        temp = src.parent / f".tmp_rename_{id(entry)}_{src.name}"
        src.rename(temp)
        temp_map.append((temp, resolved, src))

    # --- Phase 2: temp → final target ---
    try:
        for temp, resolved, original_src in temp_map:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            temp.rename(resolved)
    except Exception:
        # Best-effort rollback of phase 2 failures
        for temp, resolved, original_src in temp_map:
            if temp.exists():
                try:
                    temp.rename(original_src)
                except OSError:
                    pass
        raise

    # --- Write rollback journal ---
    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    rollback_name = f".rename_rollback_{ts}.json"
    rollback_path = directory / rollback_name

    journal = {
        'version': 1,
        'entries': [
            {
                'from': str(entry['source']),
                'to': str(entry['resolved']),
                'status': 'pending',
            }
            for entry in actionable
        ],
    }
    with open(rollback_path, 'w') as f:
        json.dump(journal, f, indent=2)

    print(f"Rollback file: {rollback_path}")
    return rollback_path


# ---------------------------------------------------------------------------
# Undo Renames
# ---------------------------------------------------------------------------

def undo_renames(target_path: pathlib.Path) -> int:
    """Reverse renames recorded in a rollback file.  Returns count restored."""
    if target_path.is_dir():
        # Recursively find newest rollback file
        rollback_files = list(target_path.rglob('.rename_rollback_*.json'))
        if not rollback_files:
            raise FileNotFoundError(
                f"No rollback files found under {target_path}")
        rollback_path = max(rollback_files, key=lambda p: p.stat().st_mtime)
    else:
        rollback_path = target_path

    with open(rollback_path, 'r') as f:
        journal = json.load(f)

    entries = journal.get('entries', [])
    # Filter to pending entries only (skip already done)
    pending = [e for e in entries if e.get('status') == 'pending']

    if not pending:
        # All done — clean up
        rollback_path.unlink()
        return 0

    # Collect source/target for two-phase undo
    undo_pairs: list[dict] = []
    for entry in pending:
        src = pathlib.Path(entry['to'])    # current location
        dst = pathlib.Path(entry['from'])  # original location
        undo_pairs.append({'current': src, 'original': dst, 'entry': entry})

    restored = 0

    # Phase 1: current → temp
    temp_map: list[tuple[pathlib.Path, pathlib.Path, dict]] = []
    for pair in undo_pairs:
        cur = pair['current']
        orig = pair['original']
        entry = pair['entry']
        if not cur.exists():
            entry['status'] = 'failed'
            entry['error'] = f"File not found: {cur}"
            continue
        temp = cur.parent / f".tmp_undo_{id(pair)}_{cur.name}"
        try:
            cur.rename(temp)
            temp_map.append((temp, orig, entry))
        except OSError as e:
            entry['status'] = 'failed'
            entry['error'] = str(e)

    # Phase 2: temp → original
    for temp, orig, entry in temp_map:
        try:
            orig.parent.mkdir(parents=True, exist_ok=True)
            temp.rename(orig)
            entry['status'] = 'done'
            restored += 1
        except OSError as e:
            entry['status'] = 'failed'
            entry['error'] = str(e)
            # Try to put temp back
            try:
                current_path = pathlib.Path(entry['to'])
                temp.rename(current_path)
            except OSError:
                pass

    # Check if all done
    all_done = all(e.get('status') == 'done' for e in entries)

    if all_done:
        rollback_path.unlink()
    else:
        # Write partial progress back
        with open(rollback_path, 'w') as f:
            json.dump(journal, f, indent=2)

    return restored


# ---------------------------------------------------------------------------
# Interactive Rename
# ---------------------------------------------------------------------------

def interactive_rename(resolved_plan: list[dict]) -> list[dict]:
    """Step through each entry, prompting for confirmation or edit."""
    approved: list[tuple[pathlib.Path, str, str]] = []  # (source, new_name, user_approved_target)

    plan_to_process = [e for e in resolved_plan if not e.get('unchanged', False)]

    for entry in plan_to_process:
        src = entry['source']
        proposed = entry['proposed']
        resolved = entry['resolved']

        while True:
            response = input(
                f'Rename "{src.name}" → "{resolved.name}"? [y/n/e(dit)] ').strip().lower()

            if response == 'y':
                approved.append((src, proposed, str(resolved)))
                break
            elif response == 'n':
                break
            elif response == 'e':
                new_name = input('  Enter new name: ').strip()
                if not new_name:
                    continue
                # If no extension provided, preserve original
                if '.' not in new_name:
                    new_name = new_name + src.suffix
                approved.append((src, new_name, str(src.parent / new_name)))
                break

    if not approved:
        return []

    # Reconciliation via resolve_target_paths
    replan = [(src, name) for src, name, _ in approved]
    user_targets = {str(src): target for src, _, target in approved}

    resolution = resolve_target_paths(replan)
    new_plan = resolution['resolved_plan']

    # Check for reconciliation mutations
    needs_reconfirm: list[int] = []
    for i, entry in enumerate(new_plan):
        src_str = str(entry['source'])
        expected = user_targets.get(src_str)
        if expected and str(entry['resolved']) != expected:
            needs_reconfirm.append(i)

    if needs_reconfirm:
        print("\n⚠ Reconciliation changed some targets. Re-confirming affected files:")
        for idx in needs_reconfirm:
            entry = new_plan[idx]
            while True:
                response = input(
                    f'  Target changed: "{entry["source"].name}" → '
                    f'"{entry["resolved"].name}" (was "{pathlib.Path(user_targets[str(entry["source"])]).name}"). '
                    f'Accept? [y/n] '
                ).strip().lower()
                if response == 'y':
                    break
                elif response == 'n':
                    new_plan[idx] = None  # Mark for removal
                    break

        new_plan = [e for e in new_plan if e is not None]

    # Re-run preview for final reconciled plan
    if new_plan:
        print("\n--- Final Reconciled Plan ---")
        preview_renames({'proposed_conflicts': resolution['proposed_conflicts'],
                         'resolved_plan': new_plan})

    return new_plan


# ---------------------------------------------------------------------------
# Custom argparse Action for ordered operations
# ---------------------------------------------------------------------------

class _AppendOperation(argparse.Action):
    """Custom Action that appends an operation dict to a shared ordered list."""

    def __call__(self, parser, namespace, values, option_string=None):
        ops = getattr(namespace, 'operations', None)
        if ops is None:
            ops = []
            setattr(namespace, 'operations', ops)

        op_type = self.dest

        if op_type == 'find_replace':
            ops.append({'type': 'find-replace', 'old': values[0], 'new': values[1]})
        elif op_type == 'regex_replace':
            ops.append({'type': 'regex-replace', 'pattern': values[0], 'repl': values[1]})
        elif op_type == 'case':
            ops.append({'type': 'case', 'mode': values})
        elif op_type == 'number':
            ops.append({'type': 'number', 'position': values[0],
                        'start': int(values[1]), 'step': int(values[2]),
                        'pad': int(values[3])})
        elif op_type == 'date_insert':
            ops.append({'type': 'date-insert', 'format': values[0],
                        'position': values[1]})
        elif op_type == 'slugify':
            ops.append({'type': 'slugify', 'separator': values})
        elif op_type == 'prefix':
            ops.append({'type': 'prefix', 'string': values})
        elif op_type == 'suffix':
            ops.append({'type': 'suffix', 'string': values})
        elif op_type == 'ext_change':
            ops.append({'type': 'ext-change', 'new_ext': values})
        elif op_type == 'trim_chars':
            ops.append({'type': 'trim-chars', 'pattern': values})
        elif op_type == 'pad_numbers':
            ops.append({'type': 'pad-numbers', 'width': int(values)})


# ---------------------------------------------------------------------------
# Main / CLI
# ---------------------------------------------------------------------------

def main() -> int:
    """Entry point.  Parses CLI, builds pipeline, runs preview, executes."""
    parser = argparse.ArgumentParser(
        prog='renamer',
        description='Batch file renaming tool')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # --- rename subcommand ---
    rename_parser = subparsers.add_parser('rename', help='Rename files')
    rename_parser.add_argument('source_dir', type=pathlib.Path,
                               help='Source directory')
    rename_parser.add_argument('glob_pattern', type=str,
                               help='Glob pattern for file selection')
    rename_parser.add_argument('--recursive', action='store_true',
                               help='Match recursively into subdirectories')
    rename_parser.add_argument('--ext-filter', type=str, default=None,
                               help='Comma-separated extensions to include')
    rename_parser.add_argument('--ext-exclude', type=str, default=None,
                               help='Comma-separated extensions to exclude')
    rename_parser.add_argument('--natural-sort', action='store_true',
                               help='Natural sort files before numbering')
    rename_parser.add_argument('--interactive', action='store_true',
                               help='Step through each file individually')
    rename_parser.add_argument('--recipe', type=str, default=None,
                               help='Path to YAML recipe file')

    # Operation flags — each uses _AppendOperation
    rename_parser.add_argument('--find-replace', nargs=2, dest='find_replace',
                               action=_AppendOperation, metavar=('OLD', 'NEW'))
    rename_parser.add_argument('--regex-replace', nargs=2, dest='regex_replace',
                               action=_AppendOperation, metavar=('PATTERN', 'REPL'))
    rename_parser.add_argument('--case', dest='case',
                               action=_AppendOperation,
                               choices=['lower', 'upper', 'title'])
    rename_parser.add_argument('--number', nargs=4, dest='number',
                               action=_AppendOperation,
                               metavar=('POS', 'START', 'STEP', 'PAD'))
    rename_parser.add_argument('--date-insert', nargs=2, dest='date_insert',
                               action=_AppendOperation,
                               metavar=('FORMAT', 'POS'))
    rename_parser.add_argument('--slugify', dest='slugify',
                               action=_AppendOperation,
                               choices=['hyphen', 'underscore'])
    rename_parser.add_argument('--prefix', dest='prefix',
                               action=_AppendOperation)
    rename_parser.add_argument('--suffix', dest='suffix',
                               action=_AppendOperation)
    rename_parser.add_argument('--ext-change', dest='ext_change',
                               action=_AppendOperation)
    rename_parser.add_argument('--trim-chars', dest='trim_chars',
                               action=_AppendOperation)
    rename_parser.add_argument('--pad-numbers', dest='pad_numbers',
                               action=_AppendOperation, type=int)

    # --- undo subcommand ---
    undo_parser = subparsers.add_parser('undo', help='Undo renames')
    undo_parser.add_argument('target', type=pathlib.Path,
                             help='Rollback file or directory')

    args = parser.parse_args()

    if args.command == 'undo':
        try:
            count = undo_renames(args.target)
            print(f"Restored {count} file(s).")
            return 0
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    # --- rename flow ---
    source_dir: pathlib.Path = args.source_dir
    glob_pattern: str = args.glob_pattern

    if not source_dir.is_dir():
        print(f"Error: {source_dir} is not a directory.", file=sys.stderr)
        return 1

    # Parse extension filters
    ext_filter = None
    if args.ext_filter is not None:
        ext_filter = [e.strip() for e in args.ext_filter.split(',')]

    ext_exclude = None
    if args.ext_exclude is not None:
        ext_exclude = [e.strip() for e in args.ext_exclude.split(',')]

    # Select files
    files = select_files(
        directory=source_dir,
        pattern=glob_pattern,
        recursive=args.recursive,
        ext_filter=ext_filter,
        ext_exclude=ext_exclude,
        natural_sort=args.natural_sort,
    )

    if not files:
        print("No files matched the selection criteria.")
        return 0

    # Build operations pipeline
    operations: list[dict] = []

    # Recipe first
    if args.recipe:
        recipe_ops = load_recipe(args.recipe)
        operations.extend(recipe_ops)

    # Then inline flags (already in order via _AppendOperation)
    inline_ops = getattr(args, 'operations', []) or []
    operations.extend(inline_ops)

    if not operations:
        print("No operations specified. Use --help for usage.")
        return 1

    # Apply operations to each file
    rename_plan: list[tuple[pathlib.Path, str]] = []
    for i, fpath in enumerate(files):
        new_name = apply_operations(fpath.name, operations, fpath, file_index=i)
        rename_plan.append((fpath, new_name))

    # Resolve targets
    resolution = resolve_target_paths(rename_plan)

    # Dry-run preview
    preview_result = preview_renames(resolution)

    # Check if anything to do
    if preview_result['summary']['to_rename'] == 0:
        print("Nothing to rename.")
        return 0

    # Interactive mode
    if args.interactive:
        final_plan = interactive_rename(resolution['resolved_plan'])
        if not final_plan:
            print("No files selected for renaming.")
            return 0
    else:
        final_plan = [e for e in resolution['resolved_plan']
                      if not e.get('unchanged', False)]

        # Confirmation
        response = input("Proceed with rename? [y/N] ").strip().lower()
        if response != 'y':
            print("Aborted.")
            return 0

    # Execute
    try:
        rollback_path = execute_renames(final_plan, source_dir)
        print(f"Successfully renamed {len(final_plan)} file(s).")
        return 0
    except Exception as e:
        print(f"Error during rename: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
