import pytest
import pathlib
import json
import sys
import datetime
from unittest.mock import patch, MagicMock

# Import the targeted implementation dynamically to ensure flexibility.
# This assumes renamer.py will be implemented in a module accessible either via PYTHONPATH
# or in the parent directory based on typical project structures.
try:
    import renamer
except ImportError:
    import sys
    sys.path.append(str(pathlib.Path(__file__).parent.parent))
    import renamer

def test_natural_sort_key():
    """Verify natural sort ordering logic directly fulfills human-expectations."""
    # purely alphabetic names sort lexicographically
    assert renamer.natural_sort_key("apple") < renamer.natural_sort_key("banana")
    
    # human-natural order: file2 sorts before file10
    assert renamer.natural_sort_key("file2") < renamer.natural_sort_key("file10")
    
    # mixed strings with multiple digit groups sort correctly
    assert renamer.natural_sort_key("a10b2") < renamer.natural_sort_key("a10b10")

def test_slugify():
    """Verify text substitution and filtering behavior for slugify."""
    # accented characters are stripped (e.g., café -> cafe)
    assert renamer.slugify("café", "-") == "cafe"
    
    # spaces become the chosen separator
    assert renamer.slugify("hello world", "_") == "hello_world"
    
    # consecutive special characters collapse to a single separator
    assert renamer.slugify("hello@#$world", "-") == "hello-world"
    
    # leading/trailing separators are removed
    assert renamer.slugify("!hello!", "-") == "hello"

def test_apply_operations(tmp_path):
    """Verify chained combinations of renaming strategies against file names."""
    dummy_file = tmp_path / "test.jpg"
    dummy_file.touch()

    # each individual operation produces expected output
    ops_replace = [{"type": "find-replace", "old": "test", "new": "done"}]
    assert renamer.apply_operations("test.jpg", ops_replace, dummy_file) == "done.jpg"

    ops_regex = [{"type": "regex-replace", "pattern": "a.*b", "repl": "x"}]
    assert renamer.apply_operations("a123b.txt", ops_regex, dummy_file) == "x.txt"

    ops_case = [{"type": "case", "mode": "upper"}]
    assert renamer.apply_operations("test.txt", ops_case, dummy_file) == "TEST.txt"

    # additional individual operations coverage
    ops_prefix = [{"type": "prefix", "string": "pre_"}]
    assert renamer.apply_operations("name.txt", ops_prefix, dummy_file) == "pre_name.txt"

    ops_suffix = [{"type": "suffix", "string": "_suf"}]
    assert renamer.apply_operations("name.txt", ops_suffix, dummy_file) == "name_suf.txt"

    ops_ext = [{"type": "ext-change", "new_ext": ".md"}]
    assert renamer.apply_operations("name.txt", ops_ext, dummy_file) == "name.md"

    ops_trim = [{"type": "trim-chars", "pattern": "x"}]
    assert renamer.apply_operations("xnamex.txt", ops_trim, dummy_file) == "name.txt"

    ops_pad = [{"type": "pad-numbers", "width": 3}]
    assert renamer.apply_operations("file2.txt", ops_pad, dummy_file) == "file002.txt"

    ops_slugify = [{"type": "slugify", "separator": "_"}]
    assert renamer.apply_operations("name with space.txt", ops_slugify, dummy_file) == "name_with_space.txt"

    ops_number = [{"type": "number", "position": "suffix", "start": 2, "step": 1, "pad": 3}]
    # Allows flexible assumption that apply_operations resolves current iteration or consumes file_index implicitly.
    num_result = renamer.apply_operations("obj.txt", ops_number, dummy_file)
    assert "002" in num_result

    ops_date = [{"type": "date-insert", "format": "%Y", "position": "prefix"}]
    date_result = renamer.apply_operations("log.txt", ops_date, dummy_file)
    # the dummy_file year should appear as prefix
    mtime = dummy_file.stat().st_mtime
    assert str(datetime.datetime.fromtimestamp(mtime).year) in date_result

    # composed operations: find-replace then case change
    ops_composed = [
        {"type": "find-replace", "old": "img", "new": "photo"},
        {"type": "case", "mode": "upper"}
    ]
    assert renamer.apply_operations("img_1.jpg", ops_composed, dummy_file) == "PHOTO_1.jpg"

def test_resolve_target_paths(tmp_path):
    """Verify target path resolutions natively scope directories and append disambiguators."""
    # Build setup scenarios
    dir1 = tmp_path / "d1"
    dir2 = tmp_path / "d2"
    dir1.mkdir()
    dir2.mkdir()
    
    file1 = dir1 / "A.txt"
    file2 = dir1 / "B.txt"
    file3 = dir2 / "C.txt"
    existing = dir1 / "target.txt"
    existing.touch()
    
    file4 = dir1 / "rollback.json"
    file1.touch()
    file2.touch()
    file3.touch()
    file4.touch()

    # Intentionally mapping file1 and file2 to the same target in dir1
    # Intentionally mapping file3 to an identical basename but in dir2 (no conflict)
    # Intentionally mapping file1 to collide with `existing`
    # Intentionally mapping file4 to the reserved rollback namespace
    plan = [
        (file1, "target.txt"),
        (file2, "target.txt"), 
        (file3, "target.txt"),
        (file4, ".rename_rollback_20260408_133825_123456.json")
    ]
    
    resolution = renamer.resolve_target_paths(plan)
    resolved = resolution['resolved_plan']
    
    # The output targets must be dict objects scoped relatively/absolutely mapping uniqueness
    assert len(resolved) == 4
    targets = [res['resolved'].name for res in resolved]
    
    # The cross-directory target shouldn't conflict
    assert (dir2 / "target.txt").name in targets
    
    # The dir1 targets must be uniquely suffix-disambiguated against each other and the existing file
    assert "target_2.txt" in targets or "target_3.txt" in targets
    
    # The reserved rollback namespace must be natively disambiguated away from the exact match
    assert ".rename_rollback_20260408_133825_123456.json" not in targets
    
    # The original source sizes and mtimes should be explicitly tracked natively
    assert "stat_signature" in resolved[0]
    assert "size" in resolved[0]["stat_signature"]
    assert "mtime_ns" in resolved[0]["stat_signature"]

def test_preview_renames():
    """Verify that conflict detection correctly assesses rename mappings."""
    plan = [
        (pathlib.Path("file1.jpg"), "new1.jpg"),
        (pathlib.Path("file2.jpg"), "new1.jpg"), # simulated unresolved duplicity validation
        (pathlib.Path("file3.jpg"), "file3.jpg") # unchanged
    ]
    res_states = renamer.resolve_target_paths(plan)
    res = renamer.preview_renames(res_states)
    
    # checking required dictionary structured keys
    assert "table_rows" in res
    assert "conflicts" in res
    assert "summary" in res
    
    summary = res["summary"]
    # verify summary counts are accurate (total_matched, to_rename, unchanged, conflicts)
    assert summary.get("total_matched", -1) == 3
    assert summary.get("to_rename", -1) == 2
    assert summary.get("unchanged", -1) == 1
    assert summary.get("proposed_conflicts", -1) >= 1
    
    # correct conflict detection when two files map to the same name
    assert len(res["conflicts"]) > 0

    # table rows contain expected current/new name pairs
    rows_str = json.dumps(res["table_rows"])
    assert "file1.jpg" in rows_str and "new1.jpg" in rows_str
    assert "file3.jpg" in rows_str

def test_execute_renames_and_rollback(tmp_path):
    """Verify actual rename action changes file contents properly and tracks history."""
    file1 = tmp_path / "origin1.txt"
    file2 = tmp_path / "origin2.txt"
    file1.touch()
    file2.touch()

    plan = [
        (file1, "dest1.txt"),
        (file2, "dest2.txt")
    ]
    
    res = renamer.resolve_target_paths(plan)
    rollback_file = renamer.execute_renames(res['resolved_plan'], tmp_path)
    
    # Verify files are actually renamed on disk
    assert not file1.exists()
    assert not file2.exists()
    assert (tmp_path / "dest1.txt").exists()
    assert (tmp_path / "dest2.txt").exists()

    # Rollback JSON contains correct original -> new mappings
    assert rollback_file.exists()
    with open(rollback_file) as f:
        data = json.load(f)

        # Validating loosely to support exact and path-based key maps per interface constraints
        values_str = json.dumps(data)
        assert "dest1.txt" in values_str
        assert "origin1.txt" in values_str

def test_undo_renames(tmp_path):
    """Verify rollback operations parse and restore state from tracker log."""
    (tmp_path / "dest1.txt").touch()
        
    rollback_file = tmp_path / ".rename_rollback_123456.json"
    
    mapping = {
        "version": 1,
        "entries": [{"from": str(tmp_path / "origin1.txt"), "to": str(tmp_path / "dest1.txt"), "status": "pending"}]
    }
    with open(rollback_file, "w") as f:
        json.dump(mapping, f)

    # all renamed files are restored to original names
    restored_count = renamer.undo_renames(tmp_path)
    
    assert restored_count >= 1
    assert (tmp_path / "origin1.txt").exists()
    assert not (tmp_path / "dest1.txt").exists()
    
    # rollback JSON file is deleted after successful undo
    assert not rollback_file.exists()

def test_execute_renames_collision_with_existing(tmp_path):
    """Verify execute_renames enforces strict adherence to resolved plans and fails on unexpected filesystem mutation."""
    file1 = tmp_path / "source.txt"
    file1.touch()
    
    existing = tmp_path / "target.txt"
    existing.touch()
    
    plan = [(file1, "target.txt")]
    res = renamer.resolve_target_paths(plan)
    
    # execution should dynamically append _2 behind the scenes according to the prompt!
    renamer.execute_renames(res['resolved_plan'], tmp_path)
    assert (tmp_path / "target_2.txt").exists()

def test_load_recipe(tmp_path):
    """Verify YAML configuration lists load securely matching runtime operation formats."""
    recipe_file = tmp_path / "recipe.yaml"
    recipe_file.write_text("operations:\n  - type: case\n    mode: lower\n  - type: ext-change\n    new_ext: .png")
    
    ops = renamer.load_recipe(str(recipe_file))
    
    # Valid YAML produces correct list of operation dicts and maintains file order
    assert type(ops) is list
    assert len(ops) >= 2
    assert ops[0]["type"] == "case"
    assert ops[1]["type"] == "ext-change"

@patch("builtins.input")
def test_interactive_rename(mock_input, tmp_path):
    """Verify per-file manual responses filter and edit renaming pipelines appropriately."""
    plan = [
        (tmp_path / "f1.txt", "n1.txt"),
        (tmp_path / "f2.txt", "n2.txt"),
        (tmp_path / "f3.txt", "n3.txt")
    ]
    res = renamer.resolve_target_paths(plan)
    
    # y response includes the file in returned plan
    # n response excludes the file entirely
    # e response lets user type manual replacement name respectively
    mock_input.side_effect = ["y", "n", "e", "custom.txt"]
    
    final_plan = renamer.interactive_rename(res['resolved_plan'])
    
    # returned plan only contains approved renames
    assert len(final_plan) == 2
    assert final_plan[0]['resolved'].name == "n1.txt" or str(final_plan[0]['resolved']) == str(tmp_path / "n1.txt")
    assert "custom" in str(final_plan[1]['resolved'])

@patch("sys.argv", ["renamer.py", "--invalid_arg_xyz"])
def test_main_invalid_args():
    """Verify interface rejects malformed usage contexts."""
    with pytest.raises(SystemExit) as exc:
        renamer.main()
    
    # Correct exit code 1 (or other non-zero) on invalid arguments
    assert exc.value.code != 0

@patch("renamer.undo_renames")
def test_main_undo_dispatch(mock_undo, tmp_path):
    """Verify standard logic forks into restoration procedures when explicitly requested."""
    mock_undo.return_value = 1
    
    # Proper dispatch to undo_renames when undo subcommand is used
    with patch("sys.argv", ["renamer.py", "undo", str(tmp_path)]):
        try:
            result = renamer.main()
            if result is not None:
                assert result == 0 
        except SystemExit as exc:
            assert exc.code == 0
            
    # Subcommands routed perfectly utilizing any path format representation without breaking tests
    assert mock_undo.call_count == 1
    passed_arg = str(mock_undo.call_args[0][0])
    assert str(pathlib.Path(tmp_path)) == str(pathlib.Path(passed_arg))

def test_select_files(tmp_path):
    """Verify recursive globbing, canonical extension filtering, and natural sorting behavior matches prompt rules."""
    (tmp_path / "img10.JPG").write_text("a")
    (tmp_path / "img2.jpg").write_text("a")
    (tmp_path / "img3.TXT").write_text("a")
    (tmp_path / "img4").write_text("a") # No extension
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "img1.jpg").write_text("a")
    
    # Recursive parsing and canonical casing filtering explicitly mapping .jpg logic across case bounds
    files = renamer.select_files(tmp_path, "img*", recursive=True, ext_filter=["jpg", ".txt"], ext_exclude=None, natural_sort=True)
    assert len(files) == 4
    file_names = [f.name for f in files]
    # Check natural sort order applied mechanically across the batch
    assert file_names.index("img1.jpg") < file_names.index("img2.jpg")
    assert file_names.index("img2.jpg") < file_names.index("img10.JPG")
    
    # Check canonical empty extension handling matches explicitly
    empty_ext_files = renamer.select_files(tmp_path, "img*", recursive=False, ext_filter=[""], ext_exclude=None, natural_sort=True)
    assert len(empty_ext_files) == 1
    assert empty_ext_files[0].name == "img4"

def test_execute_renames_drift_detection(tmp_path):
    """Verify execute checks previously validated sizes and explicitly aborts preventing clobber collisions on drift."""
    file1 = tmp_path / "drift.txt"
    file1.touch()
    
    plan = [(file1, "target.txt")]
    res = renamer.resolve_target_paths(plan)
    
    # Manually emulate file mutation post-resolve validation sequence triggering immediate drift!
    file1.write_text("mutated payload drifting execution verification parameters")
    
    # The application MUST explicitly refuse payload processing via raising exceptions per the prompt.
    with pytest.raises(Exception):
        renamer.execute_renames(res['resolved_plan'], tmp_path)
        
def test_undo_renames_partial_failure(tmp_path):
    """Verify durable partial rollback failure handling safely updates specific indices without deleting the aggregate log."""
    (tmp_path / "recover_success.txt").touch()
    
    rollback_file = tmp_path / ".rename_rollback_123457.json"
    mapping = {
        "version": 1,
        "entries": [
            {"from": str(tmp_path / "recover_fail.txt"), "to": str(tmp_path / "vanished_fail.txt"), "status": "pending"},
            {"from": str(tmp_path / "recover_success.txt"), "to": str(tmp_path / "recover_success.txt"), "status": "pending"}
        ]
    }
    with open(rollback_file, "w") as f:
        json.dump(mapping, f)

    # Missing file "vanished_fail" guarantees partial internal failure logic processing during list traversal!
    restored_count = renamer.undo_renames(tmp_path)
    
    # Should safely return partial recovery counts exactly bypassing immediate fatal breaks during iteration.
    assert restored_count == 1
    assert rollback_file.exists()  # Must not be deleted on partial failures!
    
    # Individual status flags must log updates individually per the explicit interface tracking standard.
    with open(rollback_file) as f:
        data = json.load(f)
        assert data["entries"][0]["status"] == "failed"
        assert data["entries"][1]["status"] == "done"

@patch("builtins.input")
def test_interactive_rename_reprompt(mock_input, tmp_path):
    """Verify dynamic mapping forces users into reprompt confirmation blocks aggressively across collision changes explicitly!"""
    file1 = tmp_path / "file1.txt"
    file2 = tmp_path / "file2.txt"
    file1.touch()
    file2.touch()
    
    plan = [
        (file1, "target1.txt"),
        (file2, "target2.txt")
    ]
    res = renamer.resolve_target_paths(plan)
    
    # Simulates: File 1 confirms natively ('y'). File 2 aggressively tries an 'e'dit overriding matching target1 !
    # This manually forces renamer.py's reconciliation algorithm to bump duplicate `target1_2.txt` causing a diff trigger.
    # Therefore, the script is forced to reprompt user explicitly for File 2 ('y' on second pass to affirm the updated string).
    mock_input.side_effect = ["y", "e", "target1.txt", "y"]
    
    final_plan = renamer.interactive_rename(res['resolved_plan'])
    
    assert mock_input.call_count == 4
    assert len(final_plan) == 2
    assert "target1.txt" in str(final_plan[0]['resolved'])
    assert "target1_2.txt" in str(final_plan[1]['resolved'])
